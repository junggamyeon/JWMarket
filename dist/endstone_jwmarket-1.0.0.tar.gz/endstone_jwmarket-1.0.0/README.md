# JWMarket

JWMarket is an advanced, fully-featured **Auction House and Black Market** plugin for Minecraft Bedrock (Endstone API). It relies on [JWEconomy](https://github.com/your-repo/jweconomy) to handle transactions, providing a safe, automated, and highly interactive player-driven economy.

What makes JWMarket stand out is its **native UI Forms**, **Buy Orders Escrow system**, and **Perfect NBT Serialization**, allowing players to trade heavily enchanted, named, and modified items without fear of data loss.

## 🌟 Key Features

- **Interactive Native GUI:** Forget chat-based commands! JWMarket uses beautiful, native Bedrock UI forms for browsing, searching, listing, and buying items.
- **Sell Listings (Auction House):** Players can hold an item and list it on the market for a specified price. Other players can browse the GUI and purchase it instantly.
- **Buy Orders (Escrow System):** A revolutionary feature. Players can place a "Buy Order" for an item they *want*. The money is immediately taken from their account and held in **escrow**. Other players can then fulfill this order by bringing the requested items, instantly receiving the escrowed money.
- **100% NBT Preservation:** JWMarket uses a custom JSON serializer. When an item is listed, all its data—Enchantments, Custom Names, Lore, Durability, and exact Item States—are perfectly serialized into the database and completely restored when purchased or reclaimed.
- **Offline Delivery & Reclaim System:** If a player buys your item while you are offline, or if your listing expires, the items/money are kept completely safe. Players can use the "Expired / Reclaim" menu to safely retrieve their items.
- **Categorization & Search Engine:** Items are grouped into configurable categories (Blocks, Tools, Misc, etc.). The GUI also features a live search function to find exact item matches.
- **Listing Tax System:** Server owners can configure a tax percentage applied when players list items, helping to prevent market spam and control inflation.
- **Full Localization:** Every GUI Title, Button text, and chat message is 100% configurable in the `messages.yml` file, supporting full translation into any language.

---

## 🛠️ Commands & Permissions

| Command | Permission Node | Description |
|---|---|---|
| `/ah` | `jwmarket.command.ah` | Opens the main Black Market GUI. |
| `/ah sell <price> [amount]` | `jwmarket.command.ah` | Lists the item currently held in your main hand on the market. |
| `/ah search <keyword>` | `jwmarket.command.ah` | Quickly searches the market and opens a GUI with the results. |
| `/ah expired` | `jwmarket.command.ah` | Opens the GUI to view and reclaim expired, cancelled, or safely-stored items. |
| `/ah reload` | `jwmarket.command.ah.reload` | **(Admin)** Reloads `config.yml`, `categories.yml`, and `messages.yml`. |
| `/orders` | `jwmarket.command.ah` | Opens the Buy Orders GUI to browse requests or create a new order. |

---

## ⚙️ How the Systems Work

### The Auction House (Selling)
1. A player holds a Diamond Sword with Sharpness V in their hand.
2. They type `/ah sell 5000`.
3. The item is removed from their hand, serialized to JSON (saving the Sharpness V), and placed in the SQLite database.
4. Player B opens `/ah`, browses to "Tools & Weapons", sees the sword, and clicks "Buy".
5. Player B pays 5000 coins (handled via JWEconomy). The 5000 coins are transferred to Player A, and Player B receives the exact Sharpness V sword.

### Buy Orders (Escrow)
1. Player A needs 64 Diamonds but nobody is selling them.
2. Player A uses the GUI to create a Buy Order for `minecraft:diamond`, quantity `64`, price `100` each.
3. Total cost is `6400`. The server immediately deducts `6400` from Player A and holds it in the "Escrow" database.
4. Player B mines 64 Diamonds, opens `/orders`, clicks Player A's order, and clicks "Fulfill".
5. Player B's diamonds are taken, and Player B immediately receives the `6400` coins from escrow. The diamonds are placed into Player A's offline storage (reclaim menu).

---

## 📝 Configuration Files

JWMarket generates three highly customizable files in its data folder:

### 1. `config.yml`
Controls the core mechanics of the market.
```yaml
market:
  listing_tax_percent: 5.0 # Tax charged to LIST an item.
  order_tax_percent: 2.0 # Tax charged to CREATE a buy order.
  max_active_listings: 15 # Max items a player can sell at once.
  max_active_orders: 5 # Max buy orders a player can have at once.
  default_listing_duration_hours: 48 # How long until an item expires.
  default_order_duration_hours: 72 # How long until a buy order expires.
  min_listing_price: 1.0 # Minimum price for any listing/order.
  max_listing_price: 1000000000.0 # Maximum allowed price.
  disabled_items: # Items completely banned from the market.
    - "minecraft:bedrock"
    - "minecraft:barrier"
```

### 2. `categories.yml`
Controls the categories shown in the Main Menu GUI. You can add your own categories, set the display name, choose an icon, and define which `minecraft:id` items belong inside it.
```yaml
blocks:
  display_name: "Blocks"
  icon: "textures/blocks/grass_side_carried"
  items:
    - "minecraft:dirt"
    - "minecraft:stone"
    - "minecraft:cobblestone"
```

### 3. `messages.yml`
Contains every single string of text used in the plugin. If you want to change the language to Vietnamese, Spanish, etc., or just change the color codes of the UI, do it here!

---

## 📥 Dependencies
- **Endstone API:** The core bedrock server API.
- **JWEconomy:** Required to handle currency transactions. Ensure JWEconomy is loaded before JWMarket.
